 function Timer() {
 var count = 10;
    for(i=0 ; i<10; i++ ) {
    setTimeout(function() {
        //it wouldn't count down from 10 unless i put the double minus after i
    document.getElementById("Countdown").innerHTML = i-- ;

    
    if (count <= 5){
        document.getElementById("Countdown").innerHTML = "Warning half way Done" + count + "<br>";
    }
    count=count-1;
    
}, 1000*i);
} 
    } 
    setTimeout(function(){ alert("BLASTOFF!!!")
    }, 11000);

   