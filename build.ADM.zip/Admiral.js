 function Timer() {
 var count = 10;
    for(i=0 ; i<10; i++ ) {
    setTimeout(function() {
        //it wouldn't count down from 10 unless i put the double minus after i
    document.getElementById("Countdown").innerHTML = i-- ;

    
    if (count <= 5){
        document.getElementById("Countdown").innerHTML = "Warning half way Done" + count + "<br>";
    }
    count=count-1;
    
}, 1000*i);
} 
    } 
 
    function checkcred(){
//alert("in creds");

var dpgame = document.getElementById("newplayer").value;
var teamcount = document.getElementById("teams").value;
if(dpgame.length > 25 || dpgame.length < 2){
    document.getElementById("newgamestatus").innerHTML = "Name Too Short";
}
    //length of players per team
else if(teamcount > 10 || teamcount < 1){
document.getElementById("newgamestatus").innerHTML = " Not Enough Players";
}
 else { alert ("Congrats Hope you have fun!!");
    location.replace("building.html");
}

 }
 
  

   